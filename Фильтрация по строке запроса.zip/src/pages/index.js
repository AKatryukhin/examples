import { CountryPage } from './country';
import { PersonPage } from './person';
import { HomePage } from './home';
import { ListPage } from './list';

export { CountryPage, PersonPage, HomePage, ListPage };
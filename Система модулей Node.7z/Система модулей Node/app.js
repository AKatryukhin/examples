const { getMainPage, postForm } = require('./routes');

const { router } = require('./routes');


const http = require('http');

const { PORT = 3000 } = process.env;

const { mainPageMarkup, submitSuccessMarkup } = require('./views');


const server = http.createServer(router);



server.listen(3000); 
const path = require('path');
const fs = require('fs');
const http = require('http');
const { generateMainView } = require('./views');

const { PORT = 3000 } = process.env;

const server = http.createServer((req, res) => {
  
  const dataPath = path.join(__dirname, 'data.json'); 
  
fs.readFile(dataPath, { encoding: 'utf8' }, (err, data) => {
    if (err) {
        console.log(err)
        return;
    }
  const songs = JSON.parse(data);
  const markup = generateMainView(songs);
   res.writeHead(200, {
    'Content-Type': 'text/html'
  });



  res.end(markup);
 
}); 
 
});
 
server.listen(PORT);

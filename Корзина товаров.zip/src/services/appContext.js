import React from 'react';

export const TotalPriceContext = React.createContext(null);
export const DiscountContext = React.createContext(null);
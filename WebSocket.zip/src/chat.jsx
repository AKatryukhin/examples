import React, { useCallback, useEffect, useRef, useState } from 'react';
import styles from './chat.module.css';
import { Message } from './message';
import { Input } from './input';
import sendIcon from './images/send.svg';
import { getMessages, getUser, getWsConnected } from './redux/selectors';
import { useDispatch, useSelector } from 'react-redux';
import { wsSendMessage } from './redux/actions';
import { WS_CONNECTION_START } from './redux/action-types';
import { joinChat } from './redux/thunks';

const Chat = () => {
  const dispatch = useDispatch();
  const messages = useSelector(getMessages);
  const { user } = useSelector(getUser);
  const isConnected = useSelector(getWsConnected);

  const [value, setValue] = useState('');
  const messagesContainerRef = useRef(null);

  useEffect(
    () => {
      if (user) {
        dispatch({ type: WS_CONNECTION_START });
      }
    },
    [user] // eslint-disable-line react-hooks/exhaustive-deps
  );

  useEffect(() => {
    dispatch(joinChat());
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const scrollToBottom = useCallback(
    () => {
      if (messagesContainerRef.current) {
        messagesContainerRef.current.scrollTo(0, messagesContainerRef.current.scrollHeight);
      }
    },
    [messagesContainerRef]
  );

  useEffect(
    () => {
      scrollToBottom();
    },
    [messages, scrollToBottom]
  );

  const submit = useCallback(
    () => {
      if (isConnected && user && !!value.trim()) {
        dispatch(wsSendMessage({ message: value }));
        setValue('');
      }
    },
    [value, user, dispatch, isConnected]
  );

  useEffect(
    () => {
      const listener = event => {
        if (event.code === 'Enter' || event.code === 'NumpadEnter') {
          event.preventDefault();
          submit();
        }
      };
      document.addEventListener('keydown', listener);
      return () => {
        document.removeEventListener('keydown', listener);
      };
    },
    [submit]
  );

  const onChange = useCallback(e => {
    setValue(e.target.value);
  }, []);

  const buttonLabel = isConnected ? 'Отправить сообщение' : 'Ошибка подключения';

  if (user) {
    return (
      <div className={styles.container}>
        <div className={styles.messagesWrapper} ref={messagesContainerRef}>
          {messages.map((m, index) => (
            <Message message={m} key={index} isOwnMessage={user.id === m.id} />
          ))}
        </div>
        <div className={styles.replyBar}>
          <Input
            placeholder={buttonLabel}
            onChange={onChange}
            value={value}
            disabled={!isConnected}
          />
          <img
            className={isConnected ? styles.activeButton : styles.inactiveButton}
            height="auto"
            src={sendIcon}
            alt="send"
            onClick={submit}
          />
        </div>
      </div>
    );
  }
  return null;
};

export default Chat;
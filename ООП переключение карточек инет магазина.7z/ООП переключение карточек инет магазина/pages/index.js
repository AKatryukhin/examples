import {
  defaultCardButton,
  horizontalCardButton,
  cardListSelector, items
} from '../utils/constants.js';

import Section from '../components/Section.js'

const defaultCardList = new Section([...items], cardListSelector);

defaultCardButton.addEventListener('click', () => {
   defaultCardList.renderItems([...items], cardListSelector)
});

horizontalCardButton.addEventListener('click', () => {
  defaultCardList.renderItems([...items], cardListSelector)
});

defaultCardList.renderItems()

